<?php 

$host = "localhost";
$user = "root";
$pass =  "123456789";
$db = "newbd" ;

$usuario = $_POST['usuario'];
$cont = $_POST['contraseña'];



$conexion =  mysqli_connect($host,$user,$pass, $db);

if (!$conexion) {
    die("Connection failed: " . mysqli_connect_error());
}

$sql = "SELECT nombre_usuario, contraseña_usuario, estado_usuario FROM usuarios WHERE nombre_usuario = $usuario and contraseña_usuario=$cont";

/*$sql = "SELECT nombre_usuario, contraseña_usuario, estado_usuario FROM usuarios WHERE nombre_usuario = $usuario";*/

$busqueda = mysqli_query($conexion, $sql);

if (mysqli_num_rows($busqueda) > 0 ) {
    // output data of each row
    while($row = mysqli_fetch_assoc($busqueda)) {
        echo "Bienvenido, ingreso Exitoso";
    }
} else {
        echo "error al ingresar";
}

mysqli_close($conexion);

 ?>