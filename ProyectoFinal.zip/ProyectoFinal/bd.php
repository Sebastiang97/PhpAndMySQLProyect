<?php
$host = "localhost";
$user = "root";
$pass = "12345678";


$conexion = mysqli_connect($host, $user, $pass);

if (!$conexion) {
    die("Connection failed: " . mysqli_connect_error());
}


$sql = "CREATE DATABASE newbd";

if (mysqli_query($conexion, $sql)) {
    echo "Base de datos creada correctamente";
} else {
    echo "Error creando base de datos: " . mysqli_error($conexion);
}

mysqli_close($conexion);
?> 

