<?php 

$host = "localhost";
$user = "root";
$pass =  "12345678";
$db = "mydb" ;

$nombreProducto = $_POST['nombreProducto'];
$codProducto = $_POST['codProducto'];
$marcaProducto = $_POST['marcaProducto'];
$cantProducto = $_POST['cantProducto'];



$conexion =  mysqli_connect($host,$user,$pass, $db);

if (!$conexion) {
    die("Connection failed: " . mysqli_connect_error());
}

$sql = "UPDATE productos SET Nombre='$nombreProducto', Marca='$marcaProducto' , Cantidad='$cantProducto'  WHERE Codigo='$codProducto'";


if (mysqli_query($conexion, $sql)) {
    echo "Informacion actualizada ";
} else {
    echo "error en la actualizacion ". mysqli_error($conexion);
}

mysqli_close($conexion);

 ?>