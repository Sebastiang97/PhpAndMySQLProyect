<?php 

$host = "localhost";
$user = "root";
$pass =  "123456789";
$db = "newbd" ;

$usuario = $_POST['usuario'];
$cont = $_POST['contraseña'];


$conexion =  mysqli_connect($host,$user,$pass, $db);

if (!$conexion) {
    die("Connection failed: " . mysqli_connect_error());
}

$sql = "INSERT INTO usuarios (id, nombre_usuario, contraseña_usuario, estado)
VALUES ('$id','$usuario', '$cont' , '$estado')";





if (mysqli_query($conexion, $sql)) {
    echo "Datos grabados satisfactoriamente";
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conexion);
}

mysqli_close($conexion);

 ?>