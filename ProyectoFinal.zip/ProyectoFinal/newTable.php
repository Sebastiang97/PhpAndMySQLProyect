 <?php
$host = "localhost";
$user = "root";
$pass = "12345678";
$bd = "newbd";

$conexion = mysqli_connect($host, $user, $pass, $bd);


if (!$conexion) {
    die("Connection failed: " . mysqli_connect_error());
}


$sql = "CREATE TABLE NewTable (
Codigo INT(30) PRIMARY KEY,
Nombre VARCHAR(30) NOT NULL,
Apellido VARCHAR(30) NOT NULL,
email VARCHAR(50),
reg_date TIMESTAMP
)";

if (mysqli_query($conexion, $sql)) {
    echo "Tabla creada correctamente";
} else {
    echo "Error creando tabla: " . mysqli_error($conexion);
}

mysqli_close($conexion);
?> 