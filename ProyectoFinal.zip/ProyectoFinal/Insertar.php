<?php 

$host = "localhost";
$user = "root";
$pass =  "12345678";
$db = "mydb" ;

$nombreProducto = $_POST['nombreProducto'];
$codProducto = $_POST['codProducto'];
$marcaProducto = $_POST['marcaProducto'];
$cantProducto = $_POST['cantProducto'];


if(isset($nombreProducto) && !empty($nombreProducto) && 
	isset($codProducto) && !empty($codProducto) &&
	isset($marcaProducto) && !empty($marcaProducto) &&
	isset($cantProducto) && !empty($cantProducto))
{
	echo "faltan datos";
}

$conexion =  mysqli_connect($host,$user,$pass, $db);

if (!$conexion) {
    die("Connection failed: " . mysqli_connect_error());
}

$sql = "INSERT INTO productos (Codigo, Nombre, Marca, Cantidad)
VALUES ('$codProducto', '$nombreProducto', '$marcaProducto', '$cantProducto')";


if (mysqli_query($conexion, $sql)) {
    echo "Datos grabados satisfactoriamente";
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conexion);
}

mysqli_close($conexion);

 ?>