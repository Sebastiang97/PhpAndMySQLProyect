<?php 

$host = "localhost";
$user = "root";
$pass =  "12345678";
$db = "mydb" ;


$codProducto = $_POST['codProducto'];



$conexion =  mysqli_connect($host,$user,$pass, $db);

if (!$conexion) {
    die("Connection failed: " . mysqli_connect_error());
}

$sql = "SELECT Codigo, Nombre, Marca, Cantidad FROM productos WHERE Codigo=$codProducto";

$busqueda = mysqli_query($conexion, $sql);

if (mysqli_num_rows($busqueda) > 0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($busqueda)) {
        echo "Codigo del producto: " . $row["Codigo"]."<br>". "Producto: " . $row["Nombre"]."<br>". " Marca: " . $row["Marca"]."<br>". "Cantidad: " . $row["Cantidad"]."<br>";
    }
} else {
        echo "No existe un registro con este id,
  <a href='form_insertar.html'>Inserte un registro</a>";
}

mysqli_close($conexion);

 ?>