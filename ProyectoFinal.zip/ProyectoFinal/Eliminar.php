<?php 

$host = "localhost";
$user = "root";
$pass =  "12345678";
$db = "mydb" ;


$codProducto = $_POST['codProducto'];



$conexion =  mysqli_connect($host,$user,$pass, $db);

if (!$conexion) {
    die("Connection failed: " . mysqli_connect_error());
}

$sql = "DELETE FROM productos WHERE Codigo=$codProducto";

if (mysqli_query($conexion, $sql)) {
    echo "Registro eliminado";
} else {
    echo "Error eliminado registro: " .  msqli_error($conexion);
}

mysqli_close($conexion);

 ?>