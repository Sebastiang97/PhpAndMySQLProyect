<?php 

$server = "localhost";
$user = "root";
$pass =  "12345678";
$db = "mydb";
$conexion =  mysqli_connect($server,$user,$pass,$db);



 ?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="css/bootstrap.min.css" media="screen">
    <link rel="stylesheet" href="css/style.css">
    <title>FoxElectronis</title>
  </head>
  <body>
   <div class="container">
     <header>
      <div class="row" style="background-color: #F5F6CE" >
        <div class="col-lg-12" align="center" >
          <h1>Fox Electronics</h1>
        </div>
      </div>
      <nav>

      <div class="row" id="navegacion" style="background-color: #FAAC58">
        <div class="col-lg-3" id="nav"><a href="admin.html">Administrador</a></div>
        <div class="col-lg-3" id="nav"><a href="inventario.html">Inventario</a></div>
        <div class="col-lg-3" id="nav"><a href="Ventas.html">Ventas</a></div>
        <div class="col-lg-3" id="nav"><a href="utilidades.html">Utilidades</a></div>
      </div>
     </nav>
     </header>

   <div class="row" id="cont" style="background-color: #F5F6CE">
      <div class="col-lg-12" align="center" >
        <img src="img/LogoFox.png" class="img-rounded" width="1000px">
      </div>
      <div class="col-lg-12" id="footer" align="center">
        <p>Jacques Sanabria Garcia </p>
      </div>
    </div>

  </div>

  </body>
</html>
